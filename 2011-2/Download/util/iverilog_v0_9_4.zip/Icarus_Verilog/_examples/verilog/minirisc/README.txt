//------------------------------------------------------------------------------
// Project:     minirisc: IVI example showing basic usage.
// File:        README.txt
// Description: brief description
// History:     2003iv17, FB, created.
//------------------------------------------------------------------------------

This example details basic usage of IVI and the following methods:
- how to compile verilog sources with IVI do-scripts
- how to run simulation with IVI do-scripts
- how to customize the Waveform Viewer with IVI do-scripts

To run this example:
* Start IVI.
* Enter 'cd' commands to navigate to the directory containing this example.
* Enter 'do risc_core.do' to complile this design and start simulation.

//------------------------------------------------------------------------------
// end of file
