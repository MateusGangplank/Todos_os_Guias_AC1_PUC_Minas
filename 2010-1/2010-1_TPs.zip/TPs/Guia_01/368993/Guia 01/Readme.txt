Theldo, tentei fazer os programas para sexta, s� que n�o tinha conseguido configurar meu computador e tava com algumas d�vidas.
.
Como � a primeira lista, espero que possa ter mais considera��o!!
.
O arquivo cont�m os 3 exercicios mais os extras!
.
Obrigado pela aten��o!
Bernardo Mesquita