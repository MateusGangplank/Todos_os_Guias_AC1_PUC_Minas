module meiaSoma;

reg a, b;
wire s1, s2, s3;

initial begin
$display("Criando uma meia-soma.");
$monitor("%b %b %b %b %b", a, b, s1, s2, s2 );

#1 a = 0; b = 0;
#1 a = 1; b = 0;
#1 a = 0; b = 1;
#1 a = 1; b = 1;

s1 = a + b;
s2 = ~(a * b);
s3 = s1 * s2;

end

endmodule


	
	