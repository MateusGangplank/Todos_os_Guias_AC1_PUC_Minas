//------------------------------------------------------------------------------
// Project:     vendor_lib: IVI example showing use of vendor-specific libs
// File:        README.txt
// Description: brief description
// History:     2003iv17, FB, created.
//------------------------------------------------------------------------------

This example details the use of ~/.ivi/ivi.conf and the vlib_dirs parameter.

Start with editing your ivi.conf by adding an IVerilog section, and 
a vlib_dirs parameter. The vlib_dirs parameter should point to the
desired location of your vendor-specific Verilog libraries. The following
snippet details this. 

	section IVerilog {
    	current vlib_dirs "/Users/fbertram/Library/Verilog/unisims"
	}
	
Move the file FDCE.v included with this example to the directory specified
during the previous step.

Start IVI.

Enter 'cd' commands to navigate to the directory containing this example.

Enter 'do vendor_lib.do' to complile this design and start simulation.

//------------------------------------------------------------------------------
// end of file
