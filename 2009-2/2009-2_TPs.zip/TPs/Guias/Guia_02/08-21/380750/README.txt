Trabalho Guia 02
Bruno Motta Azevedo do Nascimento
380750
Arquitetura de Computadores