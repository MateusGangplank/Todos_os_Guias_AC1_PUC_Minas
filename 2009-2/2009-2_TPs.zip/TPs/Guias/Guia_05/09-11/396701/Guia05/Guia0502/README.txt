Theldo,
	N�o foi inclu�do para o exercicio02 a complementa��o Logisim e 
        nem o resultado dos testes ao final do c�digo-fonte do programa. 
        Isso ocorreu porque n�o consegui estruturar o circuito com sucesso, 
        de maneira semelhante ao circuito somador: 
        constatei que a tabela-verdade resultante  possu�a diversos erros. 
        (algumas opera��es estavam corretas, mas por exemplo, opera��es como 00 - 01, 
        em vez de resultar 101, resultavam um inesperado 111). 
        Tentei encontrar erros de sintaxe ou de l�gica no programa, mas n�o tive �xito. 
        Conclu� que a falha se localiza no 'wiring' do vem-um do 
        circuito de diferen�a completa em associa��o ao de meia-diferen�a, 
        por�m n�o consegui alter�-lo ao ponto de que a tabela-verdade 
        resultante fosse correta.
	Tamb�m n�o encontrei refer�ncias concretas a circuitos subtratores na Internet. 
        Tirarei d�vidas na pr�xima aula de AC.

Cordialmente,
Henrique N.

OBS.:  S      S
       0|00 - 0|01
       0|00 + 1|11 = COMPLEMENTO DE DOIS
              1|11 <- RESULTADO