module clock ( clock );
 output clock;
 reg    clock;

 initial
  begin
   clock = 1'b0;
  end

 always
  begin
   #12 clock = ~clock;
  end
endmodule


module trigger ( signal, clock );
 input   clock;
 output signal;
 reg    signal;

 always 
  begin
  #120 signal = 1'b1;
  #120 signal = 1'b0;
  end
endmodule 

module ex4;

 wire  clock;
 clock clk ( clock );
 wire  t1;
 trigger trigger1 ( t1, clock );


 initial begin
  $display ("Isabella Castelo Branco Ribeiro - 380772");
  $display ("Guia 10 - Exercicio 04.");
  $dumpfile ( "ex4.vcd" );
  $dumpvars ( 1, clock, t1 );

  #960 $finish;
 end

endmodule 