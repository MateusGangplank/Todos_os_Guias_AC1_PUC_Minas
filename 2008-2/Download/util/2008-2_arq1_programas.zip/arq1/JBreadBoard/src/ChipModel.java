/*
 *
 * ChipModel.java
 *
 *
 * This is the interface that has to implemented to model a chip.
 *
 */
 

package jbreadboard.v1_00;
 
public interface ChipModel {
	
	//Set the access to the chip
	public void setAccess(jbreadboard.ChipAccess a);
 	
 	//The actual simulation method
 	public void simulate();
 	//Called when simulation is reset
 	//useful for resetting internal state
 	public void reset();
 	
 	//Chip Information
 	public String getChipText();
 	public String getDescription();
 	public String getManufacturer();

	//File name for diagram
 	public String getDiagram();
 	
 	//Chip Size
 	public int getNumberOfPins();
 	public boolean isWide();
 	
 	//get type of pin i
 	//valid pin types are:
 	//OUT   Output
 	//CLO	Clocking Output (eg from clock)
 	//IO	In/Out
 	//OCO	Open Collector Output
 	//IN	Input
 	//NC	Not Connected
	public String getPinType(int i);
 	
 	
 	//Derivatives
 	
 	//Should return an array of strings of derivaties
 	//eg {"7400","74ls00","74s00","5400",etc...}
 	public String[] getDerivatives();
 	public int getDerivative();
	//Should return array of package types corresponding to selected derivative
	//eg fo 5400 should return {"J","W"}
 	public String[] getPackages();
 	public int getPackage();

 	//select the particular derivative and package
 	//numbers based on array indicies of the arrays returned from the getters
 	public void setDerivative(int t);
 	public void setPackage(int p);
 	
}