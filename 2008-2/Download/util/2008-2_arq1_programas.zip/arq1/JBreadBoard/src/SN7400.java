/*
 *
 * SN7400.java
 *
 */
 
package chips; 
 
public class SN7400 implements jbreadboard.v1_00.ChipModel {
	private jbreadboard.ChipAccess chip;
	
	//Chip Information
	private final String Description	="Quadruple 2-Input Positive-Nand Gates";
	private final String Manufacturer	="Texas Instruments";

	//Diagram
	//NB. The SN5400W has a different pinout to the rest of the range.
	private String Diagram				="SN7400.gif";
	private String Diagram5400W			="SN5400W.gif";

	//Chip Size
	private final int NumberOfPins		=7;
	private final boolean Wide			=false;


	//Pin Types
	private final String[] pintypes		={"IN","IN","OUT","IN","IN","OUT","IN",
										  "OUT","IN","IN","OUT","IN","IN","IN"};
	private final String[] pintypes5400W={"IN","IN","OUT","IN","OUT","IN","IN",
										  "OUT","IN","IN","IN","IN","IN","OUT"};
										  


	
	//Derivatives
	private int Derivative				=3;	//7400
	private int PackageType				=0;	//N
	private final String[] Derivatives	={"SN5400",
										  "SN54LS00",
										  "SN54S00",
										  "SN7400",
										  "SN74LS00",
										  "SN74S00"};

	//Package Types
	//Corresponds to the Derivative above
	private final String[][] PackageTypes={{"J","W"},
										  {"J","W"},
										  {"J","W"},
										  {"N"	  },
										  {"D","N"},
										  {"D","N"}};
										  
	//Switching Characteristics
	private int Tplh() {
		if(Derivative==0 || Derivative==3) return 22;
		else if(Derivative==1 || Derivative==4) return 15;
		else return 5;
	}
		
	private int Tphl() {
		if(Derivative==0 || Derivative==3) return 15;
		else if(Derivative==1 || Derivative==4) return 15;
		else return 5;
	}
		
	/* 
	 *	Methods
	 */
	
	//Simulation
	public void reset() {}
	
	public void simulate() {
		boolean powered=false;
		
		//pins		
		int vcc=13;
		int gnd=6;
		int a1=0, a2=3, a3=8, a4=11;
		int b1=1, b2=4, b3=9, b4=12;
		int y1=2, y2=5, y3=7, y4=10;
		
		if(getChipText().equals("SN5400W")) {
			vcc=3;
			gnd=10;
			
			a1=0; a2=5; a3=8; a4=11;
			b1=1; b2=6; b3=9; b4=12;
			y1=2; y2=4; y3=7; y4=13;
		}
				
		if(chip.readTTL(vcc).equals("HIGH") && chip.readTTL(gnd).equals("LOW")) powered=true;
		
		//Using !equals(low) instead of equals(high) causes inputs to float high
		if(powered) {
			if(!(!chip.readTTL(a1).equals("LOW") && !chip.readTTL(b1).equals("LOW"))) 
				chip.write(y1,"HIGH",Tplh());
			else chip.write(y1,"LOW",Tphl());
			
			if(!(!chip.readTTL(a2).equals("LOW") && !chip.readTTL(b2).equals("LOW"))) 
				chip.write(y2,"HIGH",Tplh());
			else chip.write(y2,"LOW",Tphl());
			
			if(!(!chip.readTTL(a3).equals("LOW") && !chip.readTTL(b3).equals("LOW"))) 
				chip.write(y3,"HIGH",Tplh());
			else chip.write(y3,"LOW",Tphl());
			
			if(!(!chip.readTTL(a4).equals("LOW") && !chip.readTTL(b4).equals("LOW"))) 
				chip.write(y4,"HIGH",Tplh());
			else chip.write(y4,"LOW",Tphl());
		} else {
			//standard power off events
			for(int i=0;i<getNumberOfPins()*2;i++) {
				String type=getPinType(i);
				if(!(type.equals("IN") || type.equals("NC")))
					chip.write(i,"NC",0);
			}
		}
	}
	
	public void setAccess(jbreadboard.ChipAccess a) {
		chip=a;
	}
	
	//Chip Information
 	public String getChipText() {
 		return Derivatives[Derivative] + PackageTypes[Derivative][PackageType];
 	}
 	
 	public String getDescription() {
 		return Description;
 	}
 	
 	public String getManufacturer() {
 		return Manufacturer;
 	}
 
  	//Diagram
 	public String getDiagram() {
		if(getChipText().equals("SN5400W")) return Diagram5400W;
 		else return Diagram;
 	}
 	
 	//Chip Size
 	public int getNumberOfPins() {
 		return NumberOfPins;
 	}
 
 	public boolean isWide() {
 		return Wide;
 	}
 	
 	//Pin Types
 	public String getPinType(int i) {
 		if(getChipText().equals("SN5400W")) return pintypes5400W[i];
 		else return pintypes[i];
 	}
 	
 	//Derivatives
 	public int getDerivative() {return Derivative;}
 	public int getPackage() {return PackageType;}	
 	public String[] getDerivatives() {
 		return Derivatives;
 	}
 	public String[] getPackages() {
 		return PackageTypes[Derivative];
 	}
 	
 	//select the particular derivative
 	public void setDerivative(int t) {
 		Derivative = t;
 	}
 	//select the particular package
 	public void setPackage(int p) {
 		PackageType = p;
 	}
}