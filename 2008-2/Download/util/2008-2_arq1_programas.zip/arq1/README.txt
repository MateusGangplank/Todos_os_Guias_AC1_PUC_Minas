PUC-Minas - Instituto de Informatica - 2008-2

Pacote de programas para fundamentos de sistemas digitais

Itens

- CPUSim v.3.5.1
- IVI v.0.4          (adaptado)
- JBreadBoard v.1.0a (adaptado)
- JFast V.1.3
- Logisim v.2.1.6 

Instalacao

O arquivo compactado deve ser expandido em uma pasta
de sua prefer�ncia.

Os atalhos (.lnk) devem ser verificados e 
os arquivos terminados em (.bat) devem ser editados
para ajuste dos caminhos (path).

Recomenda-se testar previamente o funcionamento de
todos os programas, mesmo que nao haja uso imediato.

Para usar o compilador de Verilog (IVI),
abrir uma janela para comandos (Iniciar -> cmd)
na pasta onde foram instalados os programas e
chamar o programa IVI (IVI.bat).

