static String[][] ordena( double [][] m ){
		int linha = m.length ;
		int coluna = m[0].length ;
    	
    
    	String[][] matriz_ordenada = new String[linha][coluna] ;
		int pos_i = 0, pos_j=0 ;
		double max = m[0][0] ;
		for(int p=0; p<linha; p++ ){
			for( int q=0; q<coluna ; q++ ){
				for( int i=0; i<m.length; i++ ){
					for( int j=0; j<m[0].length; j++ ){
						if( m[i][j] > max ){
							max = m[i][j] ;
							pos_i = i ;
							pos_j = j ;
						}
					}
				}
				m[pos_i][pos_j] = -1 ;
				char c1 = (char)(pos_i + 'A') ;
				char c2 = (char)(pos_j + 'A') ;				
				matriz_ordenada[p][q] = c1 + "" + c2 ;
				max = 0 ;
	    	}
		}
		return matriz_ordenada ;	
	}