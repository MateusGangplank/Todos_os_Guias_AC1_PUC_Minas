PUC-Minas
Instituto de Ci�ncias Exatas e Informatica
2011-1

PUCTools Jar Library for Logisim v2.6.2 (and above)

Instructions:

1.) Copy PUCTools.jar and test.circ 
    to the same folder of Logisim.

2.) Launch Logisim,
    open test.cir
    and try it first.

    Hint: If PUCTools were not found,
          try to load it manually:

          Menu Project
           Load Library
            JAR Library

          If a Class name were asked, use

          PUCTools

3.) For future use,
    copy PUCTools.jar to the same folder
    of your circuits first, 
    and load library as mentioned above.
